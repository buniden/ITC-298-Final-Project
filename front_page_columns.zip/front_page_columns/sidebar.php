<section id="secondary_body">
	<?php if (!function_exists('dynamic_sidebar') || !dynamic_sidebar('Home Page Left')) : ?>
	<?php endif; ?>
	
	<?php if (!function_exists('dynamic_sidebar') || !dynamic_sidebar('Home Page Center')) : ?>
	<?php endif; ?>
	
	<?php if (!function_exists('dynamic_sidebar') || !dynamic_sidebar('Home Page Right')) : ?>
	<?php endif; ?>
</section> <!--end secondary_body-->